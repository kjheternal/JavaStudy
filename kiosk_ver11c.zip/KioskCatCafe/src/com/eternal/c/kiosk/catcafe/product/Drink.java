package com.eternal.c.kiosk.catcafe.product;

public class Drink extends Product {

	public Drink(String name, int price, int kcal) {
		super(name, price, kcal);
	}
	
	public int capacityDrink;

}
