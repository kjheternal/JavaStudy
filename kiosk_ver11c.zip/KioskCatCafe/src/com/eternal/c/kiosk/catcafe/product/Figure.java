package com.eternal.c.kiosk.catcafe.product;

public class Figure extends Product {

	public Figure(String name) {
		super(name);
	}

}
