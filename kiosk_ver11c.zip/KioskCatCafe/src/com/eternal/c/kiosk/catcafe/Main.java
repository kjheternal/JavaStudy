package com.eternal.c.kiosk.catcafe;

public class Main {

	public static void main(String[] args) {
		// 키오스크 클래스 객체 생성
		Kiosk kiosk = new Kiosk();
		
		// 키오스크 작동
		kiosk.Run();
	}

}
