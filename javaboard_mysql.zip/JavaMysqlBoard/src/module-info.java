module JavaMysqlBoard {
	requires java.sql;
}